<?php
require_once __DIR__ . '/api_helpers.php';
$user = aktifApiKullanici($db);
require_once __DIR__ . '/firebase_gonder.php';
$s = $db->prepare("SELECT fcm_token FROM garson_fcm_tokens WHERE yonetici_id=? AND aktif=1 ORDER BY id DESC LIMIT 1");
$s->execute([$user['id']]);
$token = $s->fetchColumn();
if (!$token) api_json(['durum' => 'error', 'mesaj' => 'Bu kullanıcı için FCM token bulunamadı. Önce uygulamadan giriş yapın.'], 404);
$sonuc = fcm_tokena_gonder($token, ['type' => 'new_call', 'cagri_id' => 0, 'masa_kodu' => 'test-masa'], 'Test Çağrısı', 'Bueno Garson APK bildirimi çalışıyor');
api_json(['durum' => $sonuc['ok'] ? 'success' : 'error', 'sonuc' => $sonuc]);
