<?php
// Bueno Garson APK - Firebase Cloud Messaging HTTP v1 gönderici
// Kurulum: Firebase Console > Project Settings > Service accounts > Generate new private key
// Dosyayı firebase-service-account.json adıyla bu dosyanın yanına koyabilirsiniz.

function fcm_base64url($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function fcm_service_account_path() {
    $paths = [
        __DIR__ . '/firebase-service-account.json',
        dirname(__DIR__) . '/firebase-service-account.json'
    ];
    foreach ($paths as $p) if (file_exists($p)) return $p;
    return __DIR__ . '/firebase-service-account.json';
}

function fcm_access_token() {
    $saPath = fcm_service_account_path();
    if (!file_exists($saPath)) throw new Exception('firebase-service-account.json bulunamadı.');
    $sa = json_decode(file_get_contents($saPath), true);
    if (!$sa || empty($sa['client_email']) || empty($sa['private_key'])) throw new Exception('Service account JSON okunamadı.');

    $cachePath = __DIR__ . '/fcm_access_token_cache.json';
    if (file_exists($cachePath)) {
        $cache = json_decode(file_get_contents($cachePath), true);
        if (!empty($cache['access_token']) && !empty($cache['expires_at']) && intval($cache['expires_at']) > time() + 60) {
            return $cache['access_token'];
        }
    }

    $now = time();
    $header = ['alg' => 'RS256', 'typ' => 'JWT'];
    $claim = [
        'iss' => $sa['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600
    ];
    $unsigned = fcm_base64url(json_encode($header)) . '.' . fcm_base64url(json_encode($claim));
    $signature = '';
    openssl_sign($unsigned, $signature, $sa['private_key'], 'sha256WithRSAEncryption');
    $jwt = $unsigned . '.' . fcm_base64url($signature);

    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $jwt
        ]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_TIMEOUT => 20
    ]);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $json = json_decode($res, true);
    if ($code < 200 || $code >= 300 || empty($json['access_token'])) {
        throw new Exception('Firebase access token alınamadı: ' . $res);
    }
    file_put_contents($cachePath, json_encode([
        'access_token' => $json['access_token'],
        'expires_at' => time() + intval($json['expires_in'] ?? 3500)
    ]));
    return $json['access_token'];
}

function fcm_project_id() {
    $sa = json_decode(file_get_contents(fcm_service_account_path()), true);
    if (empty($sa['project_id'])) throw new Exception('project_id bulunamadı.');
    return $sa['project_id'];
}

function fcm_tokena_gonder($fcmToken, array $data, $title = 'Bueno Garson', $body = 'Yeni masa çağrısı var') {
    $access = fcm_access_token();
    $projectId = fcm_project_id();
    $url = 'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send';
    $stringData = [];
    foreach ($data as $k => $v) $stringData[$k] = (string)$v;

    $payload = [
        'message' => [
            'token' => $fcmToken,
            'data' => $stringData,
            'android' => [
                'priority' => 'HIGH',
                'ttl' => '60s',
                'notification' => [
                    'channel_id' => 'bueno_waiter_calls_v1',
                    'sound' => 'alarm',
                    'title' => $title,
                    'body' => $body,
                    'notification_priority' => 'PRIORITY_MAX',
                    'visibility' => 'PUBLIC'
                ]
            ]
        ]
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $access,
            'Content-Type: application/json; charset=utf-8'
        ],
        CURLOPT_TIMEOUT => 20
    ]);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['ok' => ($code >= 200 && $code < 300), 'code' => $code, 'response' => $res];
}

function fcm_masa_garsona_uyar_mi($rol, $sorumluMasalar, $masaKodu) {
    if ($rol === 'admin' || $rol === 'moderatör') return true;
    if ($rol !== 'garson') return false;
    $liste = array_filter(array_map('trim', explode(',', (string)$sorumluMasalar)));
    if (empty($liste)) return false;
    return in_array($masaKodu, $liste, true);
}

function masaCagrisiFirebaseGonder(PDO $db, $masaKodu, $cagriId = 0) {
    $masaKodu = trim((string)$masaKodu);
    if ($cagriId <= 0 && $masaKodu !== '') {
        $s = $db->prepare("SELECT id FROM cagrilar WHERE masa_kodu=? AND durum=0 ORDER BY id DESC LIMIT 1");
        $s->execute([$masaKodu]);
        $cagriId = intval($s->fetchColumn());
    }
    $tokens = $db->query("SELECT * FROM garson_fcm_tokens WHERE aktif=1")->fetchAll(PDO::FETCH_ASSOC);
    $sent = 0;
    foreach ($tokens as $t) {
        if (!fcm_masa_garsona_uyar_mi($t['rol'] ?? '', $t['sorumlu_masalar'] ?? '', $masaKodu)) continue;
        $sonuc = fcm_tokena_gonder($t['fcm_token'], [
            'type' => 'new_call',
            'cagri_id' => $cagriId,
            'masa_kodu' => $masaKodu
        ], 'Yeni Masa Çağrısı', 'Masa ' . str_replace('-', ' ', $masaKodu) . ' garson bekliyor');
        if ($sonuc['ok']) $sent++;
        elseif (in_array(intval($sonuc['code']), [400, 404], true)) {
            $db->prepare("UPDATE garson_fcm_tokens SET aktif=0 WHERE id=?")->execute([$t['id']]);
        }
    }
    return $sent;
}

function masaCagrisiDurumFirebaseGonder(PDO $db, $masaKodu, $cagriId = 0, $type = 'call_accepted') {
    $tokens = $db->query("SELECT * FROM garson_fcm_tokens WHERE aktif=1")->fetchAll(PDO::FETCH_ASSOC);
    $sent = 0;
    foreach ($tokens as $t) {
        if (!fcm_masa_garsona_uyar_mi($t['rol'] ?? '', $t['sorumlu_masalar'] ?? '', $masaKodu)) continue;
        $sonuc = fcm_tokena_gonder($t['fcm_token'], [
            'type' => $type,
            'cagri_id' => $cagriId,
            'masa_kodu' => $masaKodu
        ], 'Çağrı Güncellendi', 'Masa çağrısı başka kullanıcı tarafından kapatıldı');
        if ($sonuc['ok']) $sent++;
    }
    return $sent;
}
