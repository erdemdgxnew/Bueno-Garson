<?php
require_once __DIR__ . '/api_helpers.php';
$user = aktifApiKullanici($db);
$fcm = trim($_POST['fcm_token'] ?? '');
if ($fcm === '') api_json(['durum' => 'error', 'mesaj' => 'FCM token yok.'], 400);

$stmt = $db->prepare("INSERT INTO garson_fcm_tokens (yonetici_id, kullanici_adi, rol, sorumlu_masalar, fcm_token, fcm_hash, aktif, son_gorulme)
VALUES (?, ?, ?, ?, ?, ?, 1, NOW())
ON DUPLICATE KEY UPDATE yonetici_id=VALUES(yonetici_id), kullanici_adi=VALUES(kullanici_adi), rol=VALUES(rol), sorumlu_masalar=VALUES(sorumlu_masalar), fcm_token=VALUES(fcm_token), aktif=1, son_gorulme=NOW()");
$stmt->execute([$user['id'], $user['kullanici_adi'], $user['rol'], $user['sorumlu_masalar'] ?? '', $fcm, hash('sha256', $fcm)]);
api_json(['durum' => 'success', 'mesaj' => 'FCM token kaydedildi.']);
