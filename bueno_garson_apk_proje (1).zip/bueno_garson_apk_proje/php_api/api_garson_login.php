<?php
require_once __DIR__ . '/api_helpers.php';
garsonApiTablolariHazirla($db);

$kadi = trim($_POST['kullanici_adi'] ?? '');
$sifre = trim($_POST['sifre'] ?? '');
if ($kadi === '' || $sifre === '') api_json(['durum' => 'error', 'mesaj' => 'Kullanıcı adı ve şifre zorunlu.'], 400);

$s = $db->prepare("SELECT * FROM yoneticiler WHERE kullanici_adi=? LIMIT 1");
$s->execute([$kadi]);
$user = $s->fetch(PDO::FETCH_ASSOC);
if (!$user) api_json(['durum' => 'error', 'mesaj' => 'Kullanıcı bulunamadı.'], 401);

$hash = $user['sifre'] ?? '';
$ok = password_verify($sifre, $hash) || hash_equals((string)$hash, (string)$sifre);
if (!$ok) api_json(['durum' => 'error', 'mesaj' => 'Şifre hatalı.'], 401);

if (!in_array($user['rol'], ['admin', 'moderatör', 'garson'], true)) api_json(['durum' => 'error', 'mesaj' => 'Bu kullanıcı uygulamaya giriş yapamaz.'], 403);

$token = bin2hex(random_bytes(32));
$db->prepare("INSERT INTO garson_api_tokens (yonetici_id, token_hash, aktif, son_gorulme) VALUES (?, ?, 1, NOW())")->execute([$user['id'], hash('sha256', $token)]);

api_json([
    'durum' => 'success',
    'api_token' => $token,
    'kullanici' => [
        'id' => intval($user['id']),
        'kullanici_adi' => $user['kullanici_adi'],
        'rol' => $user['rol'],
        'sorumlu_masalar' => $user['sorumlu_masalar'] ?? ''
    ]
]);
