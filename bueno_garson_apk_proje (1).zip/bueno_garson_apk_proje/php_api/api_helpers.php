<?php
// Bueno Garson APK API ortak yardımcılar
require_once __DIR__ . '/baglan.php';

function api_json($arr, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

function seoLinkOlusturApi($str) {
    $str = mb_strtolower($str, 'UTF-8');
    $str = str_replace(['ç', 'ğ', 'ı', 'ö', 'ş', 'ü'], ['c', 'g', 'i', 'o', 's', 'u'], $str);
    $str = preg_replace('/[^a-z0-9]/', '-', $str);
    return trim(preg_replace('/-+/', '-', $str), '-');
}

function garsonApiTablolariHazirla(PDO $db) {
    $db->exec("CREATE TABLE IF NOT EXISTS garson_api_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        yonetici_id INT NOT NULL,
        token_hash CHAR(64) NOT NULL UNIQUE,
        aktif TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        son_gorulme DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $db->exec("CREATE TABLE IF NOT EXISTS garson_fcm_tokens (
        id INT AUTO_INCREMENT PRIMARY KEY,
        yonetici_id INT NOT NULL,
        kullanici_adi VARCHAR(120) DEFAULT NULL,
        rol VARCHAR(40) DEFAULT NULL,
        sorumlu_masalar TEXT DEFAULT NULL,
        fcm_token TEXT NOT NULL,
        fcm_hash CHAR(64) NOT NULL UNIQUE,
        aktif TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        son_gorulme DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function bearerTokenAl() {
    $headers = function_exists('getallheaders') ? getallheaders() : [];
    $auth = '';
    foreach ($headers as $k => $v) {
        if (strtolower($k) === 'authorization') { $auth = $v; break; }
    }
    if (!$auth && isset($_SERVER['HTTP_AUTHORIZATION'])) $auth = $_SERVER['HTTP_AUTHORIZATION'];
    if (preg_match('/Bearer\s+(.*)$/i', $auth, $m)) return trim($m[1]);
    return '';
}

function aktifApiKullanici(PDO $db) {
    garsonApiTablolariHazirla($db);
    $token = bearerTokenAl();
    if (!$token) api_json(['durum' => 'error', 'mesaj' => 'API token yok.'], 401);
    $hash = hash('sha256', $token);
    $s = $db->prepare("SELECT y.* FROM garson_api_tokens t INNER JOIN yoneticiler y ON y.id=t.yonetici_id WHERE t.token_hash=? AND t.aktif=1 LIMIT 1");
    $s->execute([$hash]);
    $u = $s->fetch(PDO::FETCH_ASSOC);
    if (!$u) api_json(['durum' => 'error', 'mesaj' => 'Oturum geçersiz.'], 401);
    $db->prepare("UPDATE garson_api_tokens SET son_gorulme=NOW() WHERE token_hash=?")->execute([$hash]);
    return $u;
}

function kullaniciMasaYetkiliApi($rol, array $sorumluMasalar, $masaKodu) {
    if ($rol === 'admin' || $rol === 'moderatör') return true;
    if ($rol !== 'garson') return false;
    if (empty($sorumluMasalar)) return false;
    return in_array($masaKodu, $sorumluMasalar, true);
}

function cagriListesiApi(PDO $db, $rol, array $sorumluMasalar, $limit = 150) {
    $limit = max(1, min(300, intval($limit)));
    if ($rol === 'garson') {
        if (empty($sorumluMasalar)) return [];
        $in = implode(',', array_fill(0, count($sorumluMasalar), '?'));
        $q = $db->prepare("SELECT * FROM cagrilar WHERE masa_kodu IN ($in) ORDER BY durum ASC, id DESC LIMIT $limit");
        $q->execute($sorumluMasalar);
    } else {
        $q = $db->query("SELECT * FROM cagrilar ORDER BY durum ASC, id DESC LIMIT $limit");
    }
    $rows = $q->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as &$r) {
        $r['id'] = intval($r['id']);
        $r['durum'] = intval($r['durum']);
        $r['masa_gosterim'] = str_replace('-', ' ', (string)$r['masa_kodu']);
        $r['tarih_format'] = date('d.m.Y H:i:s', strtotime($r['tarih']));
    }
    return $rows;
}
