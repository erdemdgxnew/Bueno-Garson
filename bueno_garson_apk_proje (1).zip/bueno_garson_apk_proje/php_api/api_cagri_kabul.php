<?php
require_once __DIR__ . '/api_helpers.php';
$user = aktifApiKullanici($db);
$id = intval($_POST['id'] ?? 0);
if ($id <= 0) api_json(['durum' => 'error', 'mesaj' => 'Çağrı ID yok.'], 400);

$s = $db->prepare("SELECT * FROM cagrilar WHERE id=? LIMIT 1");
$s->execute([$id]);
$cagri = $s->fetch(PDO::FETCH_ASSOC);
if (!$cagri) api_json(['durum' => 'error', 'mesaj' => 'Çağrı bulunamadı.'], 404);

$sorumlu = !empty($user['sorumlu_masalar']) ? array_filter(array_map('trim', explode(',', $user['sorumlu_masalar']))) : [];
if (!kullaniciMasaYetkiliApi($user['rol'], $sorumlu, $cagri['masa_kodu'])) api_json(['durum' => 'error', 'mesaj' => 'Bu çağrıyı kabul etme yetkiniz yok.'], 403);

$db->prepare("UPDATE cagrilar SET durum=1 WHERE id=?")->execute([$id]);
if (file_exists(__DIR__ . '/firebase_gonder.php')) {
    require_once __DIR__ . '/firebase_gonder.php';
    if (function_exists('masaCagrisiDurumFirebaseGonder')) masaCagrisiDurumFirebaseGonder($db, $cagri['masa_kodu'], intval($id), 'call_accepted');
}
api_json(['durum' => 'success', 'mesaj' => 'Çağrı kabul edildi.']);
