<?php
require_once __DIR__ . '/api_helpers.php';
$user = aktifApiKullanici($db);
$sorumlu = !empty($user['sorumlu_masalar']) ? array_filter(array_map('trim', explode(',', $user['sorumlu_masalar']))) : [];
$liste = cagriListesiApi($db, $user['rol'], $sorumlu, 150);
api_json(['durum' => 'success', 'cagrilar' => $liste]);
