package com.bueno.garson

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {
    private const val CHANNEL_ID = "bueno_waiter_calls_v1"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val soundUri = Uri.parse("android.resource://${context.packageName}/${R.raw.alarm}")
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val channel = NotificationChannel(CHANNEL_ID, "Bueno Garson Çağrıları", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Masa çağrıları için yüksek öncelikli sesli bildirim kanalı"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 900, 250, 900, 250, 1200)
                setSound(soundUri, attrs)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun showCall(context: Context, cagriId: Int, masa: String, title: String = "Yeni Masa Çağrısı") {
        ensureChannel(context)
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(context, 100, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val alarmIntent = Intent(context, AlarmActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("cagri_id", cagriId)
            putExtra("masa", masa)
        }
        val alarmPending = PendingIntent.getActivity(context, 101 + cagriId, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText("Masa ${masa.replace("-", " ")} garson bekliyor")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setVibrate(longArrayOf(0, 900, 250, 900, 250, 1200))
            .setSound(Uri.parse("android.resource://${context.packageName}/${R.raw.alarm}"))
            .setAutoCancel(false)
            .setOngoing(false)
            .setContentIntent(openPending)
            .setFullScreenIntent(alarmPending, true)
            .build()

        if (Build.VERSION.SDK_INT < 33 || ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(context).notify(2000 + cagriId, notification)
        }
    }

    fun cancel(context: Context, cagriId: Int) {
        NotificationManagerCompat.from(context).cancel(2000 + cagriId)
    }
}
