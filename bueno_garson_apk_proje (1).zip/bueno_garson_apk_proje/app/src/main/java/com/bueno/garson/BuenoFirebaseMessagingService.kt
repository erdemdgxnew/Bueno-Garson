package com.bueno.garson

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.FormBody

class BuenoFirebaseMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        val apiToken = Prefs.token(this) ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val form = FormBody.Builder().add("fcm_token", token).build()
                ApiClient.post("api_fcm_token_kaydet.php", form, apiToken)
            } catch (_: Exception) {}
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val data = message.data
        val type = data["type"].orEmpty()
        val cagriId = data["cagri_id"]?.toIntOrNull() ?: 0
        val masa = data["masa_kodu"].orEmpty()

        if (type == "call_accepted" || type == "call_deleted") {
            if (cagriId > 0) NotificationHelper.cancel(this, cagriId)
            AlarmHelper.stop(this)
            return
        }

        if (type == "new_call") {
            NotificationHelper.showCall(this, cagriId, masa)
            AlarmHelper.vibrate(this)
        }
    }
}
