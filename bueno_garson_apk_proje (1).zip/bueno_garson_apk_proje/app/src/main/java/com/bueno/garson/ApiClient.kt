package com.bueno.garson

import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ApiClient {
    const val BASE_URL = "https://buenofoca.com/"
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    fun post(path: String, form: FormBody, token: String? = null): JSONObject {
        val builder = Request.Builder()
            .url(BASE_URL + path)
            .post(form)
        if (!token.isNullOrBlank()) builder.addHeader("Authorization", "Bearer $token")
        client.newCall(builder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw Exception("Sunucu hatası: ${response.code}")
            return JSONObject(body)
        }
    }

    fun get(path: String, token: String? = null): JSONObject {
        val builder = Request.Builder().url(BASE_URL + path)
        if (!token.isNullOrBlank()) builder.addHeader("Authorization", "Bearer $token")
        client.newCall(builder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw Exception("Sunucu hatası: ${response.code}")
            return JSONObject(body)
        }
    }
}

data class Cagri(
    val id: Int,
    val masaKodu: String,
    val masaGosterim: String,
    val tarih: String,
    val durum: Int
) {
    companion object {
        fun fromJson(obj: JSONObject): Cagri = Cagri(
            id = obj.optInt("id"),
            masaKodu = obj.optString("masa_kodu"),
            masaGosterim = obj.optString("masa_gosterim", obj.optString("masa_kodu").replace("-", " ")),
            tarih = obj.optString("tarih_format", obj.optString("tarih")),
            durum = obj.optInt("durum")
        )

        fun listFrom(json: JSONArray): List<Cagri> {
            val list = mutableListOf<Cagri>()
            for (i in 0 until json.length()) list.add(fromJson(json.getJSONObject(i)))
            return list
        }
    }
}
