package com.bueno.garson

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.FormBody

class AlarmActivity : Activity() {
    private var cagriId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
        cagriId = intent.getIntExtra("cagri_id", 0)
        val masa = intent.getStringExtra("masa") ?: ""
        AlarmHelper.start(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(0xFF3F2F26.toInt())
        }
        val title = TextView(this).apply {
            text = "🛎️ Masa Çağrısı"
            textSize = 32f
            setTextColor(0xFFFFF8EC.toInt())
            gravity = Gravity.CENTER
        }
        val body = TextView(this).apply {
            text = "Masa ${masa.replace("-", " ")} garson bekliyor"
            textSize = 24f
            setTextColor(0xFFFFF8EC.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 30)
        }
        val accept = Button(this).apply {
            text = "Kabul Et"
            textSize = 20f
            setOnClickListener { acceptCall() }
        }
        val open = Button(this).apply {
            text = "Uygulamayı Aç"
            textSize = 18f
            setOnClickListener { AlarmHelper.stop(this@AlarmActivity); finish() }
        }
        root.addView(title)
        root.addView(body)
        root.addView(accept, LinearLayout.LayoutParams(-1, 140))
        root.addView(open, LinearLayout.LayoutParams(-1, 120))
        setContentView(root)
    }

    private fun acceptCall() {
        val token = Prefs.token(this) ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val form = FormBody.Builder().add("id", cagriId.toString()).build()
                ApiClient.post("api_cagri_kabul.php", form, token)
            } catch (_: Exception) {}
            runOnUiThread {
                NotificationHelper.cancel(this@AlarmActivity, cagriId)
                AlarmHelper.stop(this@AlarmActivity)
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        AlarmHelper.stop(this)
    }
}
