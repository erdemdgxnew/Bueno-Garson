package com.bueno.garson

import android.content.Context
import android.media.MediaPlayer
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

object AlarmHelper {
    private var player: MediaPlayer? = null

    fun start(context: Context) {
        try {
            if (player?.isPlaying == true) return
            player = MediaPlayer.create(context.applicationContext, R.raw.alarm).apply {
                isLooping = true
                setVolume(1f, 1f)
                start()
            }
        } catch (_: Exception) {}
        vibrate(context)
    }

    fun stop(context: Context) {
        try { player?.stop(); player?.release() } catch (_: Exception) {}
        player = null
        try { vibrator(context).cancel() } catch (_: Exception) {}
    }

    fun vibrate(context: Context) {
        try {
            val pattern = longArrayOf(0, 900, 250, 900, 250, 1200)
            val vib = vibrator(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                @Suppress("DEPRECATION") vib.vibrate(pattern, 0)
            }
        } catch (_: Exception) {}
    }

    private fun vibrator(context: Context): Vibrator {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            manager.defaultVibrator
        } else {
            @Suppress("DEPRECATION") context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }
}
