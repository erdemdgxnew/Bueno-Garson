package com.bueno.garson

import android.content.Context

object Prefs {
    private const val FILE = "bueno_garson_prefs"
    fun saveAuth(context: Context, token: String, username: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("api_token", token)
            .putString("username", username)
            .apply()
    }
    fun token(context: Context): String? = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("api_token", null)
    fun username(context: Context): String? = context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("username", null)
    fun clear(context: Context) { context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().clear().apply() }
}
