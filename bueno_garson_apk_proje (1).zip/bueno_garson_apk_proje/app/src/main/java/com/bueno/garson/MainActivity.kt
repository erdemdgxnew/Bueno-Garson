package com.bueno.garson

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.FormBody

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var lastWaitingIds = emptySet<Int>()
    private val poller = object : Runnable {
        override fun run() { loadCalls(false); handler.postDelayed(this, 8000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.ensureChannel(this)
        requestNotifications()
        if (Prefs.token(this).isNullOrBlank()) showLogin() else showCallsScreen()
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 55)
        }
    }

    private fun baseRoot(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 38, 28, 28)
            setBackgroundColor(0xFFF5EAD8.toInt())
        }
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 28f
        setTextColor(0xFF3F2F26.toInt())
        gravity = Gravity.CENTER
        setPadding(0, 0, 0, 28)
    }

    private fun showLogin() {
        handler.removeCallbacks(poller)
        root = baseRoot()
        val user = EditText(this).apply { hint = "Kullanıcı adı" }
        val pass = EditText(this).apply { hint = "Şifre"; inputType = 0x00000081 }
        val btn = Button(this).apply { text = "Giriş Yap"; textSize = 18f }
        val status = TextView(this).apply { setTextColor(0xFF8F352B.toInt()); gravity = Gravity.CENTER; setPadding(0, 20, 0, 0) }
        root.addView(title("Bueno Garson"))
        root.addView(user, LinearLayout.LayoutParams(-1, 120))
        root.addView(pass, LinearLayout.LayoutParams(-1, 120))
        root.addView(btn, LinearLayout.LayoutParams(-1, 120))
        root.addView(status)
        setContentView(root)

        btn.setOnClickListener {
            status.text = "Giriş yapılıyor..."
            btn.isEnabled = false
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val form = FormBody.Builder()
                        .add("kullanici_adi", user.text.toString())
                        .add("sifre", pass.text.toString())
                        .build()
                    val json = ApiClient.post("api_garson_login.php", form)
                    if (json.optString("durum") != "success") throw Exception(json.optString("mesaj", "Giriş başarısız"))
                    val token = json.getString("api_token")
                    Prefs.saveAuth(this@MainActivity, token, user.text.toString())
                    registerFcmToken(token)
                    runOnUiThread { showCallsScreen() }
                } catch (e: Exception) {
                    runOnUiThread { status.text = e.message ?: "Hata"; btn.isEnabled = true }
                }
            }
        }
    }

    private fun showCallsScreen() {
        root = baseRoot()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleView = TextView(this).apply { text = "Gelen Çağrılar"; textSize = 26f; setTextColor(0xFF3F2F26.toInt()) }
        val logout = Button(this).apply { text = "Çıkış"; setOnClickListener { Prefs.clear(this@MainActivity); showLogin() } }
        header.addView(titleView, LinearLayout.LayoutParams(0, 110, 1f))
        header.addView(logout, LinearLayout.LayoutParams(220, 110))
        root.addView(header)
        setContentView(ScrollView(this).apply { addView(root) })
        registerFcmToken(Prefs.token(this))
        loadCalls(true)
        handler.removeCallbacks(poller)
        handler.postDelayed(poller, 8000)
    }

    private fun registerFcmToken(apiToken: String?) {
        if (apiToken.isNullOrBlank()) return
        FirebaseMessaging.getInstance().token.addOnSuccessListener { fcm ->
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val form = FormBody.Builder().add("fcm_token", fcm).build()
                    ApiClient.post("api_fcm_token_kaydet.php", form, apiToken)
                } catch (_: Exception) {}
            }
        }
    }

    private fun loadCalls(initial: Boolean) {
        val token = Prefs.token(this) ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val json = ApiClient.get("api_cagri_liste.php", token)
                val list = Cagri.listFrom(json.getJSONArray("cagrilar"))
                runOnUiThread { renderCalls(list, initial) }
            } catch (_: Exception) {}
        }
    }

    private fun renderCalls(calls: List<Cagri>, initial: Boolean) {
        while (root.childCount > 1) root.removeViewAt(1)
        val waiting = calls.filter { it.durum == 0 }
        val waitingIds = waiting.map { it.id }.toSet()
        if (!initial && waitingIds.any { it !in lastWaitingIds }) AlarmHelper.start(this)
        if (waiting.isEmpty()) AlarmHelper.stop(this)
        lastWaitingIds = waitingIds

        if (calls.isEmpty()) {
            root.addView(TextView(this).apply { text = "Bekleyen çağrı yok"; textSize = 20f; gravity = Gravity.CENTER; setPadding(0, 90, 0, 0) })
            return
        }
        calls.forEach { call -> root.addView(callCard(call)) }
    }

    private fun callCard(call: Cagri): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 24, 26, 24)
            setBackgroundColor(if (call.durum == 0) 0xFFFFF3DC.toInt() else 0xFFEAF0D8.toInt())
            val params = LinearLayout.LayoutParams(-1, -2); params.setMargins(0, 0, 0, 22); layoutParams = params
            addView(TextView(this@MainActivity).apply { text = "#${call.id} • ${if (call.durum == 0) "Bekliyor" else "İlgilenildi"}"; textSize = 15f; setTextColor(0xFF7B6A5D.toInt()) })
            addView(TextView(this@MainActivity).apply { text = call.masaGosterim; textSize = 32f; setTextColor(0xFF3F2F26.toInt()); setPadding(0, 12, 0, 8) })
            addView(TextView(this@MainActivity).apply { text = call.tarih; textSize = 14f; setTextColor(0xFF7B6A5D.toInt()) })
            if (call.durum == 0) {
                addView(Button(this@MainActivity).apply {
                    text = "Kabul Et"
                    textSize = 19f
                    setOnClickListener { acceptCall(call.id) }
                }, LinearLayout.LayoutParams(-1, 130))
            }
        }
    }

    private fun acceptCall(id: Int) {
        val token = Prefs.token(this) ?: return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val form = FormBody.Builder().add("id", id.toString()).build()
                ApiClient.post("api_cagri_kabul.php", form, token)
            } catch (_: Exception) {}
            runOnUiThread { NotificationHelper.cancel(this@MainActivity, id); loadCalls(false) }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(poller)
        super.onDestroy()
    }
}
